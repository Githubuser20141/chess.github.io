package io.github.hulang1024.chess.user;

public class UserOnlineCounter {
    public static int online = 0;

    public static long pc = 0;

    public static long mobile = 0;

    public static int guest = 0;
}