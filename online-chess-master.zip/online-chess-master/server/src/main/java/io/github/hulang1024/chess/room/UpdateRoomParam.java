package io.github.hulang1024.chess.room;

import lombok.Data;


@Data
public class UpdateRoomParam {
    private String name;
    private String password;
}