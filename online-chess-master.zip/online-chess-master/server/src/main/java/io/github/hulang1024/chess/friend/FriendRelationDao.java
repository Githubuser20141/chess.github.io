package io.github.hulang1024.chess.friend;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface FriendRelationDao extends BaseMapper<FriendRelation> {
}