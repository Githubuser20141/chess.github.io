package io.github.hulang1024.chess.games.reversi;

import io.github.hulang1024.chess.games.GameSettings;

public class ReversiGameSettings extends GameSettings {
}