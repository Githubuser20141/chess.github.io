package io.github.hulang1024.chess.room;

import lombok.Data;


@Data
public class JoinRoomParam {
    private String password;
}