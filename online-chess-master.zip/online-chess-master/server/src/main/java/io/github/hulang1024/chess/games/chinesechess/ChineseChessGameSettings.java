package io.github.hulang1024.chess.games.chinesechess;

import io.github.hulang1024.chess.games.GameSettings;

public class ChineseChessGameSettings extends GameSettings {
}