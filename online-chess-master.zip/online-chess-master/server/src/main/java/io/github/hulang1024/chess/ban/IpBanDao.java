package io.github.hulang1024.chess.ban;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface IpBanDao extends BaseMapper<IpBan> {
}