package io.github.hulang1024.chess.games;

public class GameInitialStates {
}