export default class TimerSettings {
  gameDuration = 15;

  stepDuration = 90;

  secondsCountdown = 10;
}
