import ChessPos from "./ChessPos";
import ChessHost from "../chess_host";

export default class ChessAction {
  chess: ChessHost;

  pos: ChessPos;
}
