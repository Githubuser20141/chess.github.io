import GameSettings from "../GameSettings";

export default class ChineseChessDarkGameSettings extends GameSettings {
  canWithdraw = false;

  fullRandom = false;
}
