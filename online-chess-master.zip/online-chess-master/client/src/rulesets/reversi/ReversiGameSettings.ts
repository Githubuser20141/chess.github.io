import GameSettings from "../GameSettings";

export default class ReversiGameSettings extends GameSettings {

}
