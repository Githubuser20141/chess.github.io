export default interface ChessThemeSet {
  [theme: string]: {
    name: string
  }
}
