import GameSettings from "../GameSettings";

export default class ChineseChessGameSettings extends GameSettings {
}
