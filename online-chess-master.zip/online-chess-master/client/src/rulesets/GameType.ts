export enum GameType {
  chinesechess = 1,
  gobang = 2,
  chinesechessDark = 3,
  reversi = 4
}
