import Signal from "src/utils/signals/Signal";

export const reload = new Signal();

export const exited = new Signal();
