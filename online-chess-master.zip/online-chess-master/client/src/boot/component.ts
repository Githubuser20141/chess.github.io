import Vue from 'vue';
import UButton from 'src/components/UButton.vue';

Vue.component('u-button', UButton);
