export default class APIResult {
  code: number;
}
