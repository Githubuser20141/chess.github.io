export const githubOAuthUrl = 'https://github.com/login/oauth/authorize?client_id=5176faf64742ae0bfe84';
