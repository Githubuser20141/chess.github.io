export default interface AccessToken {
  accessToken: string;
  expiresIn: number;
}
