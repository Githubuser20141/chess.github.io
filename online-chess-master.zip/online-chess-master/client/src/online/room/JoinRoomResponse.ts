import Room from "./Room";

export default class JoinRoomResponse {
  code: number;

  room: Room;
}
