import GameSettings from "../../rulesets/GameSettings";

export default class RoomSettings {
  gameSettings: GameSettings;
}
