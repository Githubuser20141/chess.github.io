export default class SearchRoomParams {
  gameType: number | null;

  status: number | null;
}
