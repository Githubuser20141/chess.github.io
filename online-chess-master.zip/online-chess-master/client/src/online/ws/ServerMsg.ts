export default interface ServerMsg {
  code: number;
  msg: string;
  type: string;
}
