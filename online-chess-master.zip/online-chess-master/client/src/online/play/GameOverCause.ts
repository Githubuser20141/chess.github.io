enum GameOverCause {
  NORMAL= 1,
  DRAW = 2,
  WHITE_FLAG = 3,
  TIMEOUT = 4
}

export default GameOverCause;
