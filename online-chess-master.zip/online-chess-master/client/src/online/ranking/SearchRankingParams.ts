export default class SearchRankingParams {
  page = 1;

  size = 10;

  gameType: number;

  rankingBy = 1;
}
