export default class UserOnlineCounters {
  online = 0;

  pc = 0;

  mobile = 0;

  guest = 0;
}
