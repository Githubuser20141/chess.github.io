export default interface DeviceInfo {
  device: number;

  deviceOS: string;
}
