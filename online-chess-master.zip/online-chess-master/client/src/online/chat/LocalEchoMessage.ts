import Message from "./Message";

export default class LocalEchoMessage extends Message {
  constructor() {
    super(null);
  }
}
