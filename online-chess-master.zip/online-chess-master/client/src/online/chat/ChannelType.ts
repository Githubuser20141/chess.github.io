enum ChannelType {
  PUBLIC = 1,
  ROOM = 2,
  PM = 3
}

export default ChannelType;
