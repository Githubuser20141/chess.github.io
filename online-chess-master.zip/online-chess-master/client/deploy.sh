
scp -r dist/spa/* root@180.76.185.34:/home/chess/webapp
